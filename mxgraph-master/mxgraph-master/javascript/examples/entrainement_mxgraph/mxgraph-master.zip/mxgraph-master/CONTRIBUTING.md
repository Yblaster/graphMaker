No contributions to this repo, please. Everything to the upstream repo, https://github.com/jgraph/mxgraph2, that builds this one.
